package com.example.jpaaaapp.Auth;

import org.springframework.data.repository.CrudRepository;

//Подключение репозитория CRUD действий
public interface UserRepository extends CrudRepository<UserModel,Long> {

    //Поиск по логину (может быть по Username, все зависит от названия поля логина)
    UserModel findByLogin(String login);
}
