package com.example.jpaaaapp.model;

import com.example.jpaaaapp.service.Identifiable;

import com.example.jpaaaapp.service.Identifiable;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;

@Entity
public class BookModel implements Identifiable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @NotBlank(
            message = "Error"
    )
    @Size(min = 1, max = 50)
    private String title;

    @NotBlank(
            message = "Error"
    )
    @Size(min = 1, max = 50)
    private String author;

    @NotBlank(
            message = "Error"
    )
    @Size(min = 1, max = 50)
    private String genre;

    @ManyToMany(mappedBy = "books")
    private List<PersonModel> persons;

    public BookModel(int id, String title, String author, String genre, List<PersonModel> persons) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.persons = persons;
    }

    public BookModel() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public List<PersonModel> getPersons() {
        return persons;
    }

    public void setPersons(List<PersonModel> persons) {
        this.persons = persons;
    }
}