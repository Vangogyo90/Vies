package com.example.autoitog.service;

public interface Identifiable{
    int getId();
    void setId(int id);
}
