package com.example.jpaaaapp.model;

import com.example.jpaaaapp.service.Identifiable;

import javax.persistence.*;
import javax.validation.constraints.Size;

@Entity
public class PersonBookModel implements Identifiable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "id_Person")
    private PersonModel personModel;

    @ManyToOne
    @JoinColumn(name = "id_Book")
    private BookModel bookModel;

    public PersonBookModel (int id, PersonModel personModel, BookModel bookModel){
        this.id = id;
        this.bookModel = bookModel;
        this.personModel = personModel;
    }

    public PersonBookModel () {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public PersonModel getPersonModel() {
        return personModel;
    }

    public void setPersonModel(PersonModel personModel) {
        this.personModel = personModel;
    }

    public BookModel getBookModel() {
        return bookModel;
    }

    public void setBookModel(BookModel bookModel) {
        this.bookModel = bookModel;
    }
}
