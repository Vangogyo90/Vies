package com.example.jpaaaapp;

import com.example.jpaaaapp.model.*;
import com.example.jpaaaapp.service.DAOService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
@PreAuthorize("hasAnyAuthority('USER') or hasAnyAuthority('ADMIN')")
public class ShowController {
    private final DAOService daoService;

    public ShowController(DAOService daoService) {
        this.daoService = daoService;
    }

    @GetMapping("/show/{id}")
    public String show(@PathVariable("id") int id, Model model){
        model.addAttribute("person", daoService.get(id, PersonModel.class));
        return "show";
    }

    @GetMapping("/showBook/{id}")
    public String showBook(@PathVariable("id") int id, Model model){
        model.addAttribute("book", daoService.get(id, BookModel.class));
        return "showBook";
    }

    @GetMapping("/showCar/{id}")
    public String showCar(@PathVariable("id") int id, Model model){
        model.addAttribute("car", daoService.get(id, CarModel.class));
        return "showCar";
    }

    @GetMapping("/showFood/{id}")
    public String showFood(@PathVariable("id") int id, Model model){
        model.addAttribute("food", daoService.get(id, FoodModel.class));
        return "showFood";
    }

    @GetMapping("/showProducts/{id}")
    public String showProducts(@PathVariable("id") int id, Model model){
        model.addAttribute("products", daoService.get(id, ProductModel.class));
        return "showProducts";
    }

    @GetMapping("/showCategory/{id}")
    public String showCategory(@PathVariable("id") int id, Model model){
        model.addAttribute("category", daoService.get(id, CategoryModel.class));
        return "showCategory";
    }

    @GetMapping("/showPB/{id}")
    public String showPB(@PathVariable("id") int id, Model model){
        model.addAttribute("pb", daoService.get(id, PersonBookModel.class));
        return "showPB";
    }
}
