package com.example.autoitog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoItogApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutoItogApplication.class, args);
	}
}
