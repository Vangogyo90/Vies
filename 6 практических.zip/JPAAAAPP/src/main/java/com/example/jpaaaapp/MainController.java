package com.example.jpaaaapp;

import com.example.jpaaaapp.Auth.UserModel;
import com.example.jpaaaapp.model.*;
import com.example.jpaaaapp.service.DAOService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@PreAuthorize("hasAnyAuthority('USER') or hasAnyAuthority('ADMIN') or hasAnyAuthority('ROLES_MANAGER')")
public class MainController {

    private final DAOService daoService;

    public MainController(DAOService daoService) {
        this.daoService = daoService;
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("people", daoService.getAll(PersonModel.class));
        return "index";
    }

    @GetMapping("/indexBook")
    public String indexBook(Model model){
        model.addAttribute("book", daoService.getAll(BookModel.class));
        return "indexBook";
    }

    @GetMapping("/indexCar")
    public String indexCar(Model model){
        model.addAttribute("car", daoService.getAll(CarModel.class));
        return "indexCar";
    }

    @GetMapping("/indexFood")
    public String indexFood(Model model){
        model.addAttribute("food", daoService.getAll(FoodModel.class));
        return "indexFood";
    }

    @GetMapping("/indexProducts")
    public String indexProducts(Model model){
        model.addAttribute("products", daoService.getAll(ProductModel.class));
        return "indexProducts";
    }

    @GetMapping("/indexCategory")
    public String indexCategory(Model model){
        model.addAttribute("category", daoService.getAll(CategoryModel.class));
        return "indexCategory";
    }

    @GetMapping("/indexPB")
    public String indexPB(Model model){
        model.addAttribute("pb", daoService.getAll(PersonBookModel.class));
        return "indexPB";
    }
}

