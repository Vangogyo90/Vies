package com.example.jpaaaapp.model;

import com.example.jpaaaapp.service.Identifiable;

import javax.persistence.*;
import javax.validation.constraints.Size;

import java.util.List;

@Entity
public class CategoryModel implements Identifiable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Size(min = 1, max = 50)
    private String name;

    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
    private List<ProductModel> products;

    public CategoryModel (int id, String name){
        this.id = id;
        this.name = name;
    }

    public CategoryModel (int id, String name, List<ProductModel> products){
        this.id = id;
        this.name = name;
        this.products = products;
    }

    public CategoryModel() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ProductModel> getProducts() {
        return products;
    }

    public void setProducts(List<ProductModel> products) {
        this.products = products;
    }
}
