package com.example.jpaaaapp;

import com.example.jpaaaapp.model.*;
import com.example.jpaaaapp.service.DAOService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@PreAuthorize("hasAnyAuthority('USER')")
public class SearchController {
    private final DAOService daoService;

    public SearchController(DAOService daoService) {
        this.daoService = daoService;
    }

    @GetMapping("/search")
    public String search(@RequestParam(name = "search", required = false) String searchTerm, Model model) {
        if (searchTerm != null && !searchTerm.isEmpty()) {
            List<PersonModel> searchResults = daoService.searchBy(searchTerm, PersonModel.class, "name");
            model.addAttribute("people", searchResults);
        } else {
            model.addAttribute("people", daoService.getAll(PersonModel.class));
        }
        return "index";
    }

    @GetMapping("/searchBook")
    public String searchBook(@RequestParam(name = "search", required = false) String searchTerm, Model model) {
        if (searchTerm != null && !searchTerm.isEmpty()) {
            List<BookModel> searchResults = daoService.searchBy(searchTerm, BookModel.class, "title");
            model.addAttribute("book", searchResults);
        } else {
            model.addAttribute("book", daoService.getAll(BookModel.class));
        }
        return "indexBook";
    }

    @GetMapping("/searchCar")
    public String searchCar(@RequestParam(name = "search", required = false) String searchTerm, Model model) {
        if (searchTerm != null && !searchTerm.isEmpty()) {
            List<CarModel> searchResults = daoService.searchBy(searchTerm, CarModel.class, "nameCar");
            model.addAttribute("car", searchResults);
        } else {
            model.addAttribute("car", daoService.getAll(CarModel.class));
        }
        return "indexCar";
    }

    @GetMapping("/searchFood")
    public String searchFood(@RequestParam(name = "search", required = false) String searchTerm, Model model) {
        if (searchTerm != null && !searchTerm.isEmpty()) {
            List<FoodModel> searchResults = daoService.searchBy(searchTerm, FoodModel.class, "nameFood");
            model.addAttribute("food", searchResults);
        } else {
            model.addAttribute("food", daoService.getAll(FoodModel.class));
        }
        return "indexFood";
    }

    @GetMapping("/searchProducts")
    public String searchProducts(@RequestParam(name = "search", required = false) String searchTerm, Model model) {
        if (searchTerm != null && !searchTerm.isEmpty()) {
            List<ProductModel> searchResults = daoService.searchBy(searchTerm, ProductModel.class, "name");
            model.addAttribute("products", searchResults);
        } else {
            model.addAttribute("products", daoService.getAll(ProductModel.class));
        }
        return "indexProducts";
    }

    @GetMapping("/searchCategory")
    public String searchCategory(@RequestParam(name = "search", required = false) String searchTerm, Model model) {
        if (searchTerm != null && !searchTerm.isEmpty()) {
            List<CategoryModel> searchResults = daoService.searchBy(searchTerm, CategoryModel.class, "name");
            model.addAttribute("category", searchResults);
        } else {
            model.addAttribute("category", daoService.getAll(CategoryModel.class));
        }
        return "indexCategory";
    }
}
