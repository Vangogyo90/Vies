package com.example.jpaaaapp;

import com.example.jpaaaapp.model.*;
import com.example.jpaaaapp.service.DAOService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@PreAuthorize("hasAnyAuthority('ADMIN')")
public class RedactorController {

    private final DAOService daoService;

    public RedactorController(DAOService daoService) {
        this.daoService = daoService;
    }

    @GetMapping("/new")
    public String newPerson(@ModelAttribute("person") PersonModel personModel){
        return "new";
    }

    @PostMapping("/create")
    public String create(@ModelAttribute("person") PersonModel personModel){
        daoService.create(personModel);
        return "redirect:/";
    }

    @GetMapping("/newBook")
    public String newBook(Model model){
        model.addAttribute("book", new BookModel());
        return "newBook";
    }

    @PostMapping("/createBook")
    public String createBook(@ModelAttribute("book") BookModel model){
        daoService.create(model);
        return "redirect:/indexBook";
    }

    @GetMapping("/newCar")
    public String newCar(Model model){
        model.addAttribute("car", new CarModel());
        return "newCar";
    }

    @PostMapping("/createCar")
    public String createCar(@ModelAttribute("car") CarModel model){
        daoService.create(model);
        return "redirect:/indexCar";
    }

    @GetMapping("/newFood")
    public String newFood(Model model){
        model.addAttribute("food", new FoodModel());
        return "newFood";
    }

    @PostMapping("/createFood")
    public String createFood(@ModelAttribute("food") FoodModel model){
        daoService.create(model);
        return "redirect:/indexFood";
    }

    @GetMapping("/newProducts")
    public String newProducts(Model model){
        model.addAttribute("products", new ProductModel());
        return "newProducts";
    }

    @PostMapping("/createProducts")
    public String createProducts(@ModelAttribute("products") ProductModel model){
        daoService.create(model);
        return "redirect:/indexProducts";
    }

    @GetMapping("/newCategory")
    public String newCategory(Model model){
        model.addAttribute("category", new CategoryModel());
        return "newCategory";
    }

    @PostMapping("/createCategory")
    public String createCategory(@ModelAttribute("category") CategoryModel model){
        daoService.create(model);
        return "redirect:/indexCategory";
    }

    @GetMapping("/newPB")
    public String newPB(Model model){
        model.addAttribute("pb", new PersonBookModel());
        return "newPB";
    }

    @PostMapping("/createPB")
    public String createPB(@ModelAttribute("pb") PersonBookModel model){
        daoService.create(model);
        return "redirect:/indexPB";
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable("id") int id){
        daoService.delete(id, PersonModel.class);
        return "redirect:/";
    }

    @DeleteMapping("/deleteBook/{id}")
    public String deleteBook(@PathVariable("id") int id){
        daoService.delete(id, BookModel.class);
        return "redirect:/indexBook";
    }

    @DeleteMapping("/deleteCar/{id}")
    public String deleteCar(@PathVariable("id") int id){
        daoService.delete(id, CarModel.class);
        return "redirect:/indexCar";
    }

    @DeleteMapping("/deleteFood/{id}")
    public String deleteFood(@PathVariable("id") int id){
        daoService.delete(id, FoodModel.class);
        return "redirect:/indexFood";
    }

    @DeleteMapping("/deleteProducts/{id}")
    public String deleteProducts(@PathVariable("id") int id){
        daoService.delete(id, ProductModel.class);
        return "redirect:/indexProducts";
    }

    @DeleteMapping("/deleteCategory/{id}")
    public String deleteCategory(@PathVariable("id") int id){
        daoService.delete(id, CategoryModel.class);
        return "redirect:/indexCategory";
    }

    @DeleteMapping("/deletePB/{id}")
    public String deletePB(@PathVariable("id") int id){
        daoService.delete(id, PersonBookModel.class);
        return "redirect:/indexPB";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") int id, Model model){
        model.addAttribute("person", daoService.get(id, PersonModel.class));
        return "edit";
    }

    @PostMapping("/edit/{id}")
    public String update(@ModelAttribute("person") PersonModel personModel, @PathVariable("id") int id){
        daoService.update(id, personModel, PersonModel.class);
        return "redirect:/";
    }

    @GetMapping("/editBook/{id}")
    public String editBook(@PathVariable("id") int id, Model model){
        model.addAttribute("book", daoService.get(id, BookModel.class));
        return "editBook";
    }

    @PostMapping("/editBook/{id}")
    public String updateBook(@ModelAttribute("book") BookModel model, @PathVariable("id") int id){
        daoService.update(id,model, BookModel.class);
        return "redirect:/indexBook";
    }

    @GetMapping("/editCar/{id}")
    public String editCar(@PathVariable("id") int id, Model model){
        model.addAttribute("car", daoService.get(id, CarModel.class));
        return "editCar";
    }

    @PostMapping("/editCar/{id}")
    public String updateCar(@ModelAttribute("car") CarModel model, @PathVariable("id") int id){
        daoService.update(id,model, CarModel.class);
        return "redirect:/indexCar";
    }

    @GetMapping("/editFood/{id}")
    public String editFood(@PathVariable("id") int id, Model model){
        model.addAttribute("food", daoService.get(id, FoodModel.class));
        return "editFood";
    }

    @PostMapping("/editFood/{id}")
    public String updateFood(@ModelAttribute("food") FoodModel model, @PathVariable("id") int id){
        daoService.update(id,model, FoodModel.class);
        return "redirect:/indexFood";
    }

    @GetMapping("/editProducts/{id}")
    public String editProducts(@PathVariable("id") int id, Model model){
        model.addAttribute("products", daoService.get(id, ProductModel.class));
        return "editProducts";
    }

    @PostMapping("/editProducts/{id}")
    public String updateProducts(@ModelAttribute("products") ProductModel model, @PathVariable("id") int id){
        daoService.update(id,model, ProductModel.class);
        return "redirect:/indexProducts";
    }

    @GetMapping("/editCategory/{id}")
    public String editCategory(@PathVariable("id") int id, Model model){
        model.addAttribute("category", daoService.get(id, CategoryModel.class));
        return "editCategory";
    }

    @PostMapping("/editCategory/{id}")
    public String updateCategory(@ModelAttribute("category") CategoryModel model, @PathVariable("id") int id){
        daoService.update(id,model, CategoryModel.class);
        return "redirect:/indexCategory";
    }

    @GetMapping("/editPB/{id}")
    public String editPB(@PathVariable("id") int id, Model model){
        model.addAttribute("pb", daoService.get(id, PersonBookModel.class));
        return "editPB";
    }

    @PostMapping("/editPB/{id}")
    public String updatePB(@ModelAttribute("pb") PersonBookModel model, @PathVariable("id") int id){
        daoService.update(id,model, PersonBookModel.class);
        return "redirect:/indexPB";
    }
}
