package com.example.jpaaaapp.Auth;

public enum Roles_Model {
    USER
}
