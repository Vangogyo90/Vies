package com.example.jpaaaapp.Auth;

import com.example.jpaaaapp.model.ProductModel;
import com.example.jpaaaapp.service.Identifiable;

import javax.persistence.*;
import java.util.List;

@Entity
public class Roles implements Identifiable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String nameRole;

    @OneToMany(mappedBy = "roles", cascade = CascadeType.ALL)
    private List<UserModel> userModels;

    public Roles () {}

    public Roles (int id, String nameRole){
        this.id = id;
        this.nameRole = nameRole;
    }

    public Roles (int id, String nameRole, List<UserModel> userModels){
        this.id = id;
        this.nameRole = nameRole;
        this.userModels = userModels;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    public String getNameRole() {
        return nameRole;
    }

    public void setNameRole(String nameRole) {
        this.nameRole = nameRole;
    }

    public List<UserModel> getUserModels() {
        return userModels;
    }

    public void setUserModels(List<UserModel> userModels) {
        this.userModels = userModels;
    }
}
