package com.example.jpaaaapp.model;

import com.example.jpaaaapp.service.Identifiable;

import com.example.jpaaaapp.service.Identifiable;
import javax.persistence.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;

@Entity
public class PersonModel implements Identifiable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Size(min = 1, max = 50)
    private String name;

    @Size(min = 1, max = 50)
    private String secondName;

    @Size(min = 1, max = 50)
    private String patronymic;

    @ManyToMany
    @JoinTable(
            name = "PersonBook_Model",
            joinColumns = @JoinColumn(name = "id_Person"),
            inverseJoinColumns = @JoinColumn(name = "id_Book")
    )
    private List<BookModel> books;

    public  PersonModel(){}

    public PersonModel(int id, String name, String secondName, String patronymic){
        this.id = id;
        this.name = name;
        this.secondName = secondName;
        this.patronymic = patronymic;
    }

    public PersonModel(int id, String name, String secondName, String patronymic, List<BookModel> books){
        this.id = id;
        this.name = name;
        this.secondName = secondName;
        this.patronymic = patronymic;
        this.books = books;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }

    public List<BookModel> getBooks() {
        return books;
    }

    public void setBooks(List<BookModel> books) {
        this.books = books;
    }
}
