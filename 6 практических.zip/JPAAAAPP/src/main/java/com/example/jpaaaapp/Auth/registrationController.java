package com.example.jpaaaapp.Auth;

//Подключения библиотек
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Collections;


@Controller
public class registrationController {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    //Переход к страницу
    @GetMapping("/registration")
    private String RegView()
    {
        return "regis";
    }
    //Добаление
    @PostMapping("/registration")
    private String Reg(UserModel userModel, Model model)
    {
        //Поиск по логину
        UserModel user_from_db = userRepository.findByLogin(userModel.getLogin());
        if (user_from_db != null)
        {
            //Вывод ошибки в случае нахождения аккаунта
            model.addAttribute("message", "Пользователь с таким логином уже существует");
            return "regis";
        }
        //Указания остальных данных
        userModel.setActive(true);
        userModel.setRoles(new Roles(1, "USER"));
        userModel.setPassword(passwordEncoder.encode(userModel.getPassword()));
        //Сохранение данных в бд
        userRepository.save(userModel);
        //Переход на авторизацию
        return "redirect:/login";
    }
}
