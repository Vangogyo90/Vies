package com.example.jpaaaapp.Auth;

import com.example.jpaaaapp.model.CategoryModel;
import com.example.jpaaaapp.service.Identifiable;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.*;
import javax.persistence.*;

@Entity
public class UserModel implements Identifiable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String login;
    private String password;
    private boolean active;

    @ManyToOne
    @JoinColumn(name = "id_role")
    private Roles roles;

    public UserModel(int id, String login, String password, boolean active) {
        this.id = id;
        this.login = login;
        this.password = password;
        this.active = active;
    }

    public UserModel(int id, String login, String password, boolean active, Roles roles) {
        this.id = id;
        this.login = login;
        this.password = password;
        this.active = active;
        this.roles = roles;
    }

    public UserModel() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Roles getRoles() {
        return roles;
    }

    public void setRoles(Roles roles) {
        this.roles = roles;
    }
}
