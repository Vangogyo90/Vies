package com.example.jpaaaapp.model;

import com.example.jpaaaapp.service.Identifiable;

import com.example.jpaaaapp.service.Identifiable;
import javax.persistence.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import java.util.List;

@Entity
public class ProductModel implements Identifiable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Size(min = 1, max = 50)
    private String name;

    @Positive(
            message = "Error"
    )
    private double price;

    @ManyToOne
    @JoinColumn(name = "id_Category")
    private CategoryModel category;

    public ProductModel(int id, String name, double price, CategoryModel category) {
        this.name = name;
        this.price = price;
        this.category = category;
        this.id = id;
    }

    public ProductModel () {}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public CategoryModel getCategory() {
        return category;
    }

    public void setCategory(CategoryModel category) {
        this.category = category;
    }
}

