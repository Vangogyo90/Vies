package com.example.jpaaaapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaaaappApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaaaappApplication.class, args);
	}

}
