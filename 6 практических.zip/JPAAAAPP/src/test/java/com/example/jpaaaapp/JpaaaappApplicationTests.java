package com.example.jpaaaapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaaaappApplicationTests {

	@Test
	void contextLoads() {
	}

}
