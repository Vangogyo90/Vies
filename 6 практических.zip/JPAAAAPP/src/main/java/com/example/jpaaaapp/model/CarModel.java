package com.example.jpaaaapp.model;

import com.example.jpaaaapp.service.Identifiable;

import com.example.jpaaaapp.service.Identifiable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;
import javax.validation.constraints.Size;

@Entity
public class CarModel implements Identifiable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Size(min = 1, max = 50)
    private String nameCar;

    @Size(min = 1, max = 50)
    private String typeCar;

    @Size(min = 1, max = 50)
    private String oldCar;

    public  CarModel(){}

    public CarModel(int id, String nameCar, String typeCar, String oldCar){
        this.id = id;
        this.nameCar = nameCar;
        this.typeCar = typeCar;
        this.oldCar = oldCar;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNameCar() {
        return nameCar;
    }

    public void setNameCar(String nameCar) {
        this.nameCar = nameCar;
    }

    public String getTypeCar() {
        return typeCar;
    }

    public void setTypeCar(String typeCar) {
        this.typeCar = typeCar;
    }

    public String getOldCar() {
        return oldCar;
    }

    public void setOldCar(String oldCar) {
        this.oldCar = oldCar;
    }
}
