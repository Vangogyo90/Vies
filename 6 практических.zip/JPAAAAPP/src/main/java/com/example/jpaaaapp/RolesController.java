package com.example.jpaaaapp;

import com.example.jpaaaapp.Auth.UserModel;
import com.example.jpaaaapp.model.PersonModel;
import com.example.jpaaaapp.service.DAOService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@PreAuthorize("hasAnyAuthority('ROLES_MANAGER')")
public class RolesController {

    private final DAOService daoService;

    public RolesController(DAOService daoService) {
        this.daoService = daoService;
    }

    @GetMapping("/indexUser")
    public String indexUser(Model model){
        model.addAttribute("user", daoService.getAll(UserModel.class));
        return "indexUser";
    }

    @GetMapping("/editUser/{id}")
    public String editUser(@PathVariable("id") int id, Model model){
        model.addAttribute("user", daoService.get(id, UserModel.class));
        return "editUser";
    }

    @PostMapping("/editUser/{id}")
    public String updateUser(@ModelAttribute("user") UserModel model, @PathVariable("id") int id){
        daoService.update(id,model, UserModel.class);
        return "redirect:/indexUser";
    }
}
