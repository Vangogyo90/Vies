package com.example.jpaaaapp.service;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Identifiable{
    int getId();
    void setId(int id);
}
