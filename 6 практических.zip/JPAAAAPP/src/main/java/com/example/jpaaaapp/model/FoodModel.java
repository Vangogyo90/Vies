package com.example.jpaaaapp.model;

import com.example.jpaaaapp.service.Identifiable;
import com.example.jpaaaapp.service.Identifiable;
import javax.persistence.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;
import javax.validation.constraints.Size;

@Entity
public class FoodModel implements Identifiable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Size(min = 1, max = 50)
    private String nameFood;

    @Size(min = 1, max = 50)
    private String typeFood;

    @Size(min = 1, max = 50)
    private String weightFood;

    public  FoodModel(){}

    public FoodModel(int id, String nameFood, String typeFood, String weightFood){
        this.id = id;
        this.nameFood = nameFood;
        this.typeFood = typeFood;
        this.weightFood = weightFood;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNameFood() {
        return nameFood;
    }

    public void setNameFood(String nameFood) {
        this.nameFood = nameFood;
    }

    public String getTypeFood() {
        return typeFood;
    }

    public void setTypeFood(String typeFood) {
        this.typeFood = typeFood;
    }

    public String getWeightFood() {
        return weightFood;
    }

    public void setWeightFood(String weightFood) {
        this.weightFood = weightFood;
    }
}
